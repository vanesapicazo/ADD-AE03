package es.ADD.ae03;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Biblioteca {
	
	int identificador;
	String titulo;
	String autor;
	int a�o;
	String editorial;
	int paginas;
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		
		int identificador;
		String titulo;
		String autor;
		int a�o;
		String editorial;
		int paginas;
		
		
		int eleccion;
		
		System.out.print("1. Mostrar todos los t�tulos de la biblioteca");
		System.out.print("2. Mostrar informaci�n detallada de un libro");
		System.out.print("3. Crear nuevo libro");
		System.out.print("4. Actualizar libro");
		System.out.print("5. Borrar libro");
		System.out.print("6. Cerrar la biblioteca");
		
		eleccion = sc.nextInt();
		
		if(eleccion == 1) {
			recuperarTodos();
			
		} else if(eleccion == 2) {
			mostrarLibro(Libro libro);
			
		} else if(eleccion == 3) {
			crearLibro();
			
		} else if(eleccion == 4) {
			actualizaLibro(identificador);
			
		} else if(eleccion == 5) {
			borrarLibro(identificador);
			
		} else if(eleccion == 6) {
			System.out.print("Se ha cerrado la biblioteca.");
			
		}

	}
	

	int crearLibro(Libro libro) {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(new File("biblioteca.xml"));
		Element raiz = document.getDocumentElement();
		System.out.println("Contenido XML " + raiz.getNodeName() + ":");
		NodeList nodeList = document.getElementsByTagName("libro");
		int numeroNodos = nodeList.getLength();
		System.out.println("N�mero total de libros: " + nodeList.getLength());
		ArrayList<Libro> listaLibros = new ArrayList<Libro>(0);
		
		for(int i = 0; i < numeroNodos; i++) {
			Node nodo = nodeList.item(i);
			Element elemento = (Element) nodo;
			
			System.out.println("");
			System.out.println("T�tulo: " + elemento.getElementsByTagName("titulo").item(0).getTextContent());
			System.out.println("Autor: " + elemento.getElementsByTagName("autor").item(0).getTextContent());
			System.out.println("A�o publicaci�n: " + elemento.getElementsByTagName("anyo_publicacion").item(0).getTextContent());
			System.out.println("Editorial: " + elemento.getElementsByTagName("editorial").item(0).getTextContent());
			System.out.println("N� p�ginas: " + elemento.getElementsByTagName("no_paginas").item(0).
			
			Libro nuevoLibro = new Libro(identificador, titulo, autor, a�o, editorial, paginas);
			listaLibros.add(nuevoLibro);
		}
		
		Scanner teclado = new Scanner(System.in);
		Int respuesta = teclado.nextInt();
		
		while(respuesta.equals("s")) {
			System.out.println("T�tulo: "); String titulo = teclado.nextLine();
			System.out.println("Autor: "); String autor = teclado.nextLine();
			System.out.println("Editorial: "); String editorial = teclado.nextLine();
			System.out.println("N� de p�ginas: "); int paginas = teclado.nextInt();	
		}
		teclado.close();
	
		return identificador;
	}
	
	
	void mostrarLibro(Libro libro){
		toString();
	
	}
	
	
	static void borrarLibro(int identificador) {
		
	}
	
	
	static void actualizaLibro(int identificador) {
		
	}
	
	
	Libro recuperarLibro(int identificador) {
		
		return libro(identificador, titulo, autor, a�o, editorial, paginas);
	}
	
	private static Libro libro(int identificador2, String titulo2, String autor2, int a�o2, String editorial2, int paginas2) {
		// TODO Auto-generated method stub
		return null;
	}


	static ArrayList<Libro> recuperarTodos(){
		ArrayList<Libro> listaLibros = new ArrayList<Libro>();
		
		return listaLibros;
	}
	
}
