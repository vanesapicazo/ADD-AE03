package es.ADD.ae03;

public class Libro {
	
	private int identificador;
	private String titulo;
	private String autor;
	private int a�o;
	private String editorial;
	private int paginas;
	
	Libro() {}
	
	Libro(int identificador, String titulo, String autor, int a�o, String editorial, int paginas){
		this.identificador = identificador;
		this.titulo = titulo;
		this.autor = autor;
		this.a�o = a�o;
		this.editorial = editorial;
		this.paginas = paginas;
	}
	
	//SETTERS Y GETTERS
	public int getIdentificador() {
		return identificador;
	}
	
	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}
	
	
	public String getTitulo() {
		return titulo;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
	public String getAutor() {
		return autor;
	}
	
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	
	public int getA�o() {
		return a�o;
	}
	
	public void setA�o(int a�o) {
		this.a�o = a�o;
	}
	
	
	public String getEditorial() {
		return editorial;
	}
	
	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	
	
	public int getPaginas() {
		return paginas;
	}
	
	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}
	
	
	
	
	public String toString() {
		String infoBiblioteca = "-T�tulo: " + titulo + "-Autor: " + autor + "-A�o: " + a�o + "-Editorial: " + editorial + "-N� p�ginas" + paginas;
		return infoBiblioteca;
	}
}

	
